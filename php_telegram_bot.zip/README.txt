
# بوت تليجرام بسيط بلغة PHP

## طريقة الاستخدام:
1. ارفع الملفات إلى استضافة تدعم PHP (مثل Render أو InfinityFree أو cPanel).
2. اجعل رابط `index.php` هو الرابط الأساسي (Webhook).
3. اربط البوت بالرابط عبر Telegram API.
