
<?php
$TOKEN = "7997156871:AAGyfg-c9Nzw6xPPfPIP8X2Qx0UW_MMpi8k";
$update = json_decode(file_get_contents("php://input"), TRUE);
$message = $update["message"]["text"];
$chat_id = $update["message"]["chat"]["id"];

if ($message == "/start") {
    $text = "👋 أهلاً بك في بوت البداية!";
    file_get_contents("https://api.telegram.org/bot$TOKEN/sendMessage?chat_id=$chat_id&text=" . urlencode($text));
}
?>
